function searchFunct()
{
    input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    content_wrapper = document.getElementsByClassName("products content-wrapper");
    product_wrapper = document.getElementsByClassName(product_wrapper);
    
    for(int i=0;i<)
}